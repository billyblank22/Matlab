
clear;
clf; 

%initial value a
a = 0;
%some function f and derivative fp
f = @(x) exp(x)-cos(x);
fp = @(x) exp(x)+sin(x);
n = 20;

%evaluating initial value
ex = fp(a);

for i=1:n
    h(i) = (0.5-i/100);
    %finding the approximation using the calculated values
    aptaylor = (f(a-2*h(i)) - 8*f(a-h(i))+8*f(a+h(i))-f(a+2*h(i)))/(12*h(i));
    error(i) = abs(ex-aptaylor); 
    logh(i) = log10(h(i));
    logerror(i) = log10(error(i));
end

slopeVal = ((logerror(n)-logerror(1))/(logh(n)-logh(1)));
plot(logh, logerror, 'm-o');
title('Log h V. Log Error')
xlabel('Log of h');
ylabel('Log of Error');
display(slopeVal);